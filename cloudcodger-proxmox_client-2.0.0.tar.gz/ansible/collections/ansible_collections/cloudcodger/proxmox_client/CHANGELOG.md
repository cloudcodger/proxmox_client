# Change log

# version 1.5.0

- Role `cloud_init` changes.
    - Added `description` to the optional items for `cloud_init_vms`.
    - Added `cloud_init_ansible_host*` variables. See `README.md` file.
    - Added `cloud_init_agent` to enable the QEMU Guest Agent.
    - Added `cloud_init_ansible_inventory_refresh` to have the role refresh the inventory.
    - Added `cloud_init_cpu` to set the CPU type.
    - Removed the default value for `cloud_init_network_gw`.
    - Changed `cloud_init_construct_vmid_start`.
    - For `cloud_init_vms`, made the following items optional, `control`, `ip` and `vmid`.
    - Changed `cloud_init_image` default to `ubuntu-24.04-server.qcow2`.

TBD? Change `cloud_init_pm_host` default to finding the PVE node with the least memory in use.

# version 1.4.1

- Role `lxc` bug fix. Missing default for `pm_host`.

# version 1.4.0

- Role `lxc` changes.
    - Made setting `lxc_construct_cidr_start` and `lxc_construct_vmid_start` optional.
    - In `lxc_cts`, the `ip` and `vmid` are now optional.
    - Added the ability to create/update a `host_vars` file for newly created LXC containers and add/update the `ansible_host` variable to it.
    - Changed the `lxc_network_gw` default to `''`.

# version 1.3.1

- Removed `storage` from the `lxc` call to `community.general.proxmox` when creating a container.

# version 1.3.0

- Added `features` to the `lxc` (See the `README.md` for the role).
- Changed the default for `lxc_unprivileged` to `true`, to match the default in Proxmox.

# version 1.2.0

- Added `cloud_init_custom` to the `cloud_init` role for `cicustom` (See the `README.md` for the role).

# version 1.1.0

- Added optional `mounts` for LXC containers.

# version 1.0.0

- The initial release
